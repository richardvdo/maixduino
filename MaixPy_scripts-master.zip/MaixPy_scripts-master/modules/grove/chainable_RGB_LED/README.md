Grove chainable RGB LED
============


<img src="assets/grove_rgb_led.jpg" width=450px /><img src="assets/grove_rgb_led2.jpg" width=450px />

More info see :[seeed studio wiki](http://wiki.seeedstudio.com/Grove-Chainable_RGB_LED/)

## Examples


Send `RGB_LED.py` to board by `MaixPy IDE` or `upyloader` first, or just merge `RGB_LED.py` and example file to one file

* [breath](breath.py)
* [fade_inout](fade_inout.py)



