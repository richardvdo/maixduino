MaixPy Scripts
====


Scripts for [MaixPy](https://github.com/sipeed/MaixPy) ~ have a good time~

Doc of MaixPy: [maixpy.sipeed.com](https://maixpy.sipeed.com)



