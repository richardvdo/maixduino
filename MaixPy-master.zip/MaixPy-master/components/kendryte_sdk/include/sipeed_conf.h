#ifndef __SIPEED_CONF_H
#define __SIPEED_CONF_H

#define K210_DMA_CH_KPU  5

#endif