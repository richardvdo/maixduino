#ifndef _SIPEEED_TYPE_H
#define _SIPEEED_TYPE_H

#define sipeed_size_t size_t
#define sipeed_uint32_t uint32_t
#define sipeed_uint8_t  uint8_t

#endif /* _SIPEEED_TYPE_H */