#ifndef __BOARDS_H
#define __BOARDS_H

#include "global_config.h"

// #define CONFIG_LCD_DEFAULT_FREQ 15000000
// #define CONFIG_LCD_DEFAULT_WIDTH 320
// #define CONFIG_LCD_DEFAULT_HEIGHT 240

int boards_init();

#endif //__BOARDS_H

