#ifndef __M5STICK_H
#define __M5STICK_H

#include "stdbool.h"

bool m5stick_init();

#endif

