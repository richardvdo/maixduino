#ifndef __MAIXPY_H
#define __MAIXPY_H

#ifdef __cplusplus
extern "C" {
#endif

int maixpy_main();

#ifdef __cplusplus
};
#endif


#endif

