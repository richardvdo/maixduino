
#ifndef __LVGL_H_
#define __LVGL_H_

#include "lv_gc.h"
#include "py/mpstate.h"


#endif

