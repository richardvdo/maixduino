#ifndef __OV3660_H
#define __OV3660_H

#include "sensor.h"

int ov3660_init(sensor_t *sensor);

#endif // __OV3660_H

