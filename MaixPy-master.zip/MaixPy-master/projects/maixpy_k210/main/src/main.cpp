#include "maixpy.h"

void * __dso_handle = 0 ;

int main()
{
    maixpy_main();
    return 0;
}

